export type Food = { id: string; name: string; category: string; description: string; price: number; image: string; popular?: boolean }
export const categories = ['All', 'Breakfast', 'Main dishes', 'Drinks', 'Desserts']
export const foods: Food[] = [
  { id:'f1', name:'እንጀራ በዶሮ ወጥ', category:'Main dishes', description:'Traditional injera with rich chicken stew', price:280, image:'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=900', popular:true },
  { id:'f2', name:'በያይነት', category:'Main dishes', description:'A colorful selection of Ethiopian vegetarian dishes', price:240, image:'https://images.unsplash.com/photo-1547592180-85f173990554?w=900', popular:true },
  { id:'f3', name:'ፍርፍር', category:'Breakfast', description:'Soft injera pieces tossed with spiced sauce', price:180, image:'https://images.unsplash.com/photo-1513442542250-854d436a73f2?w=900' },
  { id:'f4', name:'ሽሮ ወጥ', category:'Main dishes', description:'Comforting chickpea stew with berbere', price:190, image:'https://images.unsplash.com/photo-1547592180-85f173990554?w=900' },
  { id:'f5', name:'Fresh Juice', category:'Drinks', description:'Fresh seasonal fruit juice', price:100, image:'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=900' },
  { id:'f6', name:'Cake slice', category:'Desserts', description:'A sweet treat with your meal', price:120, image:'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=900' }
]