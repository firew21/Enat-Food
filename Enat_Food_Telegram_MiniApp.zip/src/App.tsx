import { useMemo, useState } from 'react'
import { ShoppingBag, Search, Plus, Minus, ArrowLeft, CheckCircle2, MapPin, Clock3, UtensilsCrossed } from 'lucide-react'
import { categories, foods, type Food } from './data'
import { supabase } from './lib/supabase'

type Cart = Record<string, number>
type View = 'home' | 'cart' | 'success'
const currency = import.meta.env.VITE_CURRENCY || 'ETB'
const money = (n:number) => `${n.toLocaleString()} ${currency}`

export default function App() {
  const [category,setCategory] = useState('All')
  const [search,setSearch] = useState('')
  const [cart,setCart] = useState<Cart>({})
  const [view,setView] = useState<View>('home')
  const [address,setAddress] = useState('')
  const [note,setNote] = useState('')
  const [busy,setBusy] = useState(false)
  const [orderId,setOrderId] = useState('')
  const tg = window.Telegram?.WebApp
  const user = tg?.initDataUnsafe?.user
  const items = useMemo(() => foods.filter(f => (category==='All'||f.category===category) && (f.name.toLowerCase().includes(search.toLowerCase())||f.description.toLowerCase().includes(search.toLowerCase()))),[category,search])
  const count = Object.values(cart).reduce((a,b)=>a+b,0)
  const total = foods.reduce((sum,f)=>sum+f.price*(cart[f.id]||0),0)
  const add = (f:Food, delta:number) => {
    tg?.HapticFeedback?.impactOccurred('light')
    setCart(old => ({...old,[f.id]:Math.max(0,(old[f.id]||0)+delta)}))
  }
  const placeOrder = async () => {
    if (!address.trim()) { alert('Please enter your delivery address.'); return }
    setBusy(true)
    try {
      const payload = { telegram_user_id: user?.id ?? null, customer_name: user?.first_name ?? 'Guest', delivery_address: address, note, items: foods.filter(f=>cart[f.id]).map(f=>({food_id:f.id,name:f.name,quantity:cart[f.id],unit_price:f.price})), total, status:'new' }
      if (supabase) {
        const { data, error } = await supabase.from('orders').insert(payload).select('id').single()
        if (error) throw error
        setOrderId(String(data.id))
      } else {
        const id = `DEMO-${Date.now().toString().slice(-6)}`
        localStorage.setItem(id,JSON.stringify(payload)); setOrderId(id)
      }
      setCart({}); setView('success'); tg?.HapticFeedback?.notificationOccurred('success')
    } catch (e) { alert(e instanceof Error ? e.message : 'Could not place order. Please try again.') }
    finally { setBusy(false) }
  }
  if (view==='success') return <main className="success"><div className="success-icon"><CheckCircle2 size={48}/></div><h1>Order received!</h1><p>Thank you for choosing Enat Food.</p><div className="order-number">Order #{orderId}</div><button className="primary wide" onClick={()=>setView('home')}>Back to menu</button></main>
  return <main className="app-shell">
    <header className="topbar"><div className="brand-mark"><UtensilsCrossed size={22}/></div><div className="brand"><b>Enat Food</b><small>Fresh food, made with care</small></div><button className="cart-top" onClick={()=>setView('cart')} aria-label="Open cart"><ShoppingBag/><span>{count}</span></button></header>
    {view==='home' ? <>
      <section className="hero"><div><span className="eyebrow">WELCOME{user?.first_name ? `, ${user.first_name.toUpperCase()}` : ''}</span><h1>Good food.<br/><em>Good mood.</em></h1><p>Find your favorite Ethiopian flavors.</p></div><div className="hero-art">🍲</div></section>
      <div className="searchbox"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search dishes..." /></div>
      <div className="section-head"><div><span className="eyebrow">OUR MENU</span><h2>Explore dishes</h2></div><span className="muted">{items.length} items</span></div>
      <nav className="categories">{categories.map(c=><button key={c} className={category===c?'selected':''} onClick={()=>setCategory(c)}>{c}</button>)}</nav>
      <section className="food-grid">{items.map(f=><article className="food-card" key={f.id}><div className="food-image"><img src={f.image} alt={f.name}/>{f.popular&&<span className="popular">Popular</span>}</div><div className="food-info"><div className="food-title"><h3>{f.name}</h3><b>{money(f.price)}</b></div><p>{f.description}</p><div className="food-bottom">{cart[f.id]?<div className="stepper"><button onClick={()=>add(f,-1)}><Minus size={15}/></button><b>{cart[f.id]}</b><button onClick={()=>add(f,1)}><Plus size={15}/></button></div>:<button className="add-button" onClick={()=>add(f,1)}><Plus size={16}/> Add</button>}</div></div></article>)}</section>
      {count>0&&<button className="floating-cart" onClick={()=>setView('cart')}><span><ShoppingBag size={19}/> View cart · {count} items</span><b>{money(total)}</b></button>}
    </> : <section className="cart-page"><button className="back" onClick={()=>setView('home')}><ArrowLeft size={18}/> Back to menu</button><h1>Your cart</h1>{count===0?<div className="empty">Your cart is empty. Add something delicious!</div>:<><div className="cart-list">{foods.filter(f=>cart[f.id]).map(f=><div className="cart-row" key={f.id}><img src={f.image} alt=""/><div className="cart-name"><b>{f.name}</b><small>{money(f.price)} each</small></div><div className="stepper"><button onClick={()=>add(f,-1)}><Minus size={14}/></button><b>{cart[f.id]}</b><button onClick={()=>add(f,1)}><Plus size={14}/></button></div></div>)}</div><div className="checkout"><h2>Delivery details</h2><label><MapPin size={16}/> Delivery address</label><textarea value={address} onChange={e=>setAddress(e.target.value)} placeholder="Enter your area, street or landmark..." rows={2}/><label>Order note (optional)</label><input value={note} onChange={e=>setNote(e.target.value)} placeholder="Any special instructions?"/><div className="total-line"><span>Subtotal</span><b>{money(total)}</b></div><div className="total-line"><span>Delivery fee</span><span>Confirmed by restaurant</span></div><button disabled={busy} className="primary wide" onClick={placeOrder}>{busy?'Placing order...':`Place order · ${money(total)}`}</button><small className="disclaimer">Online payment is not enabled in this starter version. The restaurant can confirm payment and delivery with you.</small></div></>}</section>}
    <footer><Clock3 size={14}/> Made with care · Enat Food</footer>
  </main>
}