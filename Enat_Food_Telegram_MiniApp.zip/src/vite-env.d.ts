/// <reference types="vite/client" />
interface Window {
  Telegram?: { WebApp?: {
    ready: () => void; expand: () => void;
    initData: string; initDataUnsafe?: { user?: { id: number; first_name?: string; username?: string } };
    MainButton?: { setText: (text: string) => void; show: () => void; hide: () => void; onClick: (fn: () => void) => void; offClick: (fn: () => void) => void };
    HapticFeedback?: { impactOccurred: (style: string) => void; notificationOccurred: (type: string) => void };
    close: () => void;
  } }
}