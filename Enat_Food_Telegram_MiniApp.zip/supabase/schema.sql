-- Enat Food starter schema. Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  telegram_user_id bigint,
  customer_name text not null default 'Guest',
  delivery_address text not null,
  note text,
  items jsonb not null,
  total numeric(12,2) not null check (total >= 0),
  status text not null default 'new' check (status in ('new','accepted','preparing','ready','delivered','cancelled')),
  created_at timestamptz not null default now()
);

alter table public.orders enable row level security;

-- Starter policy: allow anonymous order creation only.
-- For production, validate Telegram initData on a trusted backend and replace this
-- with authenticated policies. Do not expose the service-role key in the browser.
drop policy if exists "public can create orders" on public.orders;
create policy "public can create orders"
on public.orders for insert
to anon, authenticated
with check (delivery_address <> '' and jsonb_typeof(items) = 'array' and total >= 0);

-- No public SELECT/UPDATE/DELETE policies are created intentionally.
