# Enat Food — Telegram Mini App starter

A mobile-first food ordering Mini App built with React + TypeScript + Vite, ready to be opened inside Telegram. It includes a menu, category filters, search, cart, delivery address, demo order flow, and optional Supabase order insertion.

## 1. Requirements
- Node.js 20+ and npm
- A Telegram account
- A Supabase project (optional for local demo; needed to persist real orders)
- A public HTTPS URL for Telegram deployment

## 2. Run locally
```bash
npm install
npm run dev
```
Open the local URL shown by Vite. Without Supabase environment variables, orders are stored in browser localStorage as a demo only.

## 3. Connect Supabase
1. Create a project at https://supabase.com.
2. Open SQL Editor and run `supabase/schema.sql`.
3. Copy Project URL and anon/public key from Project Settings → API.
4. Copy `.env.example` to `.env` and fill:
```env
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
VITE_CURRENCY=ETB
```
5. Restart `npm run dev`.

Important: Never put the Supabase service-role key in frontend code. The starter allows anonymous INSERT only and does not expose customer orders. For production, add a server-side endpoint that validates Telegram `initData` and writes orders securely.

## 4. Deploy to Vercel
1. Push this folder to a GitHub repository.
2. Import the repository at https://vercel.com.
3. Add the three `VITE_...` environment variables in Vercel Project Settings.
4. Deploy and copy the HTTPS deployment URL.

## 5. Create the Telegram bot and Mini App
1. Open Telegram and message `@BotFather`.
2. Send `/newbot`, choose a display name and a unique username, and copy the bot token privately.
3. Configure the Mini App using BotFather's Mini App / Web App settings (menu button or main app, depending on the bot setup).
4. Set the Web App URL to your Vercel HTTPS URL.
5. Open the bot and launch the Mini App.

Do not paste your bot token into this project or share it in chat. Configure bot commands and server-side token handling only after a backend endpoint is added.

## Current scope
- Working responsive menu, category filters, search, add/remove cart.
- Delivery address and note capture.
- Demo checkout. Supabase insert when configured.
- Telegram Web App ready/expand and user greeting when launched in Telegram.
- No real payment gateway, delivery fee calculation, admin dashboard, order status updates, or secure Telegram identity verification yet. These are planned next phases, not included features.

## Next development phases
1. Secure backend endpoint validating Telegram `initData`.
2. Admin dashboard with role-protected order management.
3. Menu/category management stored in Supabase.
4. Payment provider integration after merchant account and country support are confirmed.
5. Delivery fee and service-area configuration.
