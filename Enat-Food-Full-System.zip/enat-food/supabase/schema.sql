-- Enat Food database schema. Run the whole file in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'customer' check (role in ('admin','customer')),
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  category text not null default 'Main dishes',
  price numeric(10,2) not null check (price > 0),
  image_url text,
  is_available boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_code text not null unique,
  customer_name text not null,
  phone text not null,
  address text not null,
  note text not null default '',
  telegram_user_id text,
  items jsonb not null,
  total numeric(10,2) not null check (total >= 0),
  status text not null default 'new'
    check (status in ('new','confirmed','preparing','on_the_way','delivered','cancelled')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

drop policy if exists "Anyone can read available products" on public.products;
create policy "Anyone can read available products" on public.products
for select to anon, authenticated using (is_available = true or public.is_admin());

drop policy if exists "Admins manage products" on public.products;
create policy "Admins manage products" on public.products
for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "Admins read orders" on public.orders;
create policy "Admins read orders" on public.orders
for select to authenticated using (public.is_admin());

drop policy if exists "Admins update orders" on public.orders;
create policy "Admins update orders" on public.orders
for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "Users read own profile" on public.profiles;
create policy "Users read own profile" on public.profiles
for select to authenticated using (id = auth.uid() or public.is_admin());

-- Optional sample Ethiopian menu. Edit prices and names in the admin panel.
insert into public.products(name,description,category,price) values
('Doro Wot','Ethiopian spicy chicken stew served with injera','Traditional',450),
('Beyaynet','A colorful vegetarian combination served with injera','Traditional',280),
('Tibs','Sautéed beef with onion, tomato and herbs','Traditional',420),
('Shiro','Smooth chickpea stew with Ethiopian spices','Traditional',220),
('Firfir','Injera pieces mixed with berbere sauce','Breakfast',180),
('Chechebsa','Traditional spiced flatbread breakfast','Breakfast',200)
on conflict do nothing;

-- After creating your first admin user in Supabase Authentication,
-- replace THE_AUTH_USER_UUID below with that user's UUID and run:
-- insert into public.profiles(id, role) values ('THE_AUTH_USER_UUID', 'admin')
-- on conflict (id) do update set role = 'admin';
