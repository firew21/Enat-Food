# Enat Food — Telegram Mini App / Food Delivery MVP

ይህ የመጀመሪያ ሙሉ MVP ነው፦
- የምግብ ዝርዝርና ምድቦች
- Cart እና checkout
- ትዕዛዝ መፍጠር
- የትዕዛዝ ኮድ እና ሁኔታ መከታተያ
- Admin login, orders, order status update, menu management
- Telegram Mini App WebApp SDK መገናኛ

## 1. Supabase Database
1. ወደ https://supabase.com ግባና New project ፍጠር።
2. Project → SQL Editor → New query ክፈት።
3. `supabase/schema.sql` ውስጥ ያለውን ሙሉ SQL ኮፒ አድርገህ Run አድርግ።
4. Project Settings → API ውስጥ Project URL, anon key, service_role key አግኝ።
   **service_role key ሚስጥር ነው፤ በfrontend ወይም Telegram ላይ አታሳይ።**

## 2. GitHub
1. https://github.com ላይ account ፍጠር/ግባ።
2. New repository → `enat-food` → Create repository.
3. ይህን ZIP አውርድ፣ extract አድርግና ፋይሎቹን repository ውስጥ upload አድርግ።

## 3. Vercel deploy
1. https://vercel.com/new ክፈት።
2. GitHub አገናኝና `enat-food` repository ምረጥ።
3. Environment Variables ውስጥ እነዚህን ጨምር፦
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
4. Deploy ጫን።

## 4. Admin account
1. Supabase → Authentication → Users → Add user በማለት admin email/password ፍጠር።
2. የuser UUID ኮፒ አድርግ።
3. SQL Editor ውስጥ ይህን በUUID ቀይረህ Run አድርግ፦
   ```sql
   insert into public.profiles(id, role)
   values ('YOUR_AUTH_USER_UUID', 'admin')
   on conflict (id) do update set role = 'admin';
   ```
4. በVercel URL መጨረሻ `/admin` ጨምር።

## 5. Telegram Mini App
1. Telegram ውስጥ `@BotFather` ክፈት።
2. `/newbot` ብለህ bot ፍጠርና token በደህና አስቀምጥ።
3. `/newapp` ተጠቀም፣ bot ምረጥ፣ app name እና Vercel HTTPS URL አስገባ።
4. Telegram Mini App SDK በcustomer page ውስጥ ተዘጋጅቷል።

## ጠቃሚ የደህንነት ማስታወሻ
- Vercel free hosting ለመጀመሪያ ደረጃ ተስማሚ ነው፤ ሆኖም 100% uptime ዋስትና የለም።
- Supabase free plan ጥቅም ላይ ሳይውል ፕሮጀክትን pause ሊያደርግ ይችላል፤ የአሁኑን free-tier ደንቦች ከSupabase ይመልከቱ።
- ይህ MVP የክፍያ gateway ወይም የdelivery rider live GPS አያካትትም።
- የproduction ስራ ከመጀመር በፊት Telegram `initData` በbackend ማረጋገጥ፣ rate limiting፣ spam protection እና የbackup ፖሊሲ መጨመር ያስፈልጋል።
- Telegram bot token በVercel secret environment variable ውስጥ ብቻ ይቀመጥ፤ በclient code አይገባም።

## Project structure
- `app/page.tsx` — customer mini app
- `app/admin/page.tsx` — admin dashboard
- `app/api/orders/route.ts` — secure order creation endpoint
- `app/api/track/route.ts` — order tracking endpoint
- `supabase/schema.sql` — database and security policies
