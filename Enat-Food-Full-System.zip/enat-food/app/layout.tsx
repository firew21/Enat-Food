import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Enat Food | Ethiopian Food Delivery",
  description: "Order delicious food with Enat Food."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
