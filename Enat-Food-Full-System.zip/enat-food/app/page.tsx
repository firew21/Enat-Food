"use client";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";

declare global { interface Window { Telegram?: any } }
type Product = { id: string; name: string; description: string; price: number; category: string; image_url?: string; is_available: boolean };
type CartLine = { product: Product; qty: number };

export default function Home() {
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartLine[]>([]);
  const [category, setCategory] = useState("All");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [trackingCode, setTrackingCode] = useState("");
  const [trackingPhone, setTrackingPhone] = useState("");
  const [trackingResult, setTrackingResult] = useState("");
  const [telegramUser, setTelegramUser] = useState<any>(null);

  useEffect(() => {
    const tg = window.Telegram?.WebApp;
    if (tg) {
      tg.ready(); tg.expand();
      setTelegramUser(tg.initDataUnsafe?.user || null);
      if (tg.initDataUnsafe?.user?.first_name) setName(tg.initDataUnsafe.user.first_name);
    }
    supabase.from("products").select("*").eq("is_available", true).order("created_at")
      .then(({ data, error }) => { if (!error && data) setProducts(data as Product[]); });
  }, []);

  const categories = ["All", ...Array.from(new Set(products.map(p => p.category).filter(Boolean)))];
  const shown = category === "All" ? products : products.filter(p => p.category === category);
  const total = useMemo(() => cart.reduce((s, l) => s + l.product.price * l.qty, 0), [cart]);
  function add(p: Product) {
    setCart(old => old.some(l => l.product.id === p.id)
      ? old.map(l => l.product.id === p.id ? { ...l, qty: l.qty + 1 } : l)
      : [...old, { product: p, qty: 1 }]);
  }
  function change(id: string, delta: number) {
    setCart(old => old.map(l => l.product.id === id ? { ...l, qty: l.qty + delta } : l).filter(l => l.qty > 0));
  }
  async function placeOrder() {
    if (!cart.length || !name.trim() || !phone.trim() || !address.trim()) {
      setMessage("Please add items and complete your name, phone and delivery address."); return;
    }
    setBusy(true); setMessage("");
    try {
      const res = await fetch("/api/orders", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customer_name: name, phone, address, note,
          telegram_user_id: telegramUser?.id ? String(telegramUser.id) : null,
          items: cart.map(l => ({ product_id: l.product.id, quantity: l.qty }))
        })
      });
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "Could not place order");
      setMessage(`Order received! Your order code is ${result.order_code}. Save it to track your order.`);
      setCart([]);
      if (window.Telegram?.WebApp) window.Telegram.WebApp.showAlert(`Order placed: ${result.order_code}`);
    } catch (e: any) { setMessage(e.message || "Something went wrong."); }
    finally { setBusy(false); }
  }
  async function trackOrder() {
    setTrackingResult("Checking...");
    const r = await fetch(`/api/track?code=${encodeURIComponent(trackingCode)}&phone=${encodeURIComponent(trackingPhone)}`);
    const j = await r.json();
    setTrackingResult(r.ok ? `Status: ${j.status} · Total: ${j.total} ETB` : (j.error || "Order not found"));
  }

  return <main className="page">
    <header className="hero">
      <div className="brandmark">🍲</div>
      <div><div className="eyebrow">FRESH • LOCAL • DELICIOUS</div><h1>Enat <span>Food</span></h1><p>Homemade Ethiopian favorites, delivered to you.</p></div>
      <a className="adminLink" href="/admin">Admin</a>
    </header>

    <section className="section">
      <div className="sectionHead"><div><div className="eyebrow">OUR MENU</div><h2>Choose your food</h2></div><span className="pill">{products.length} items</span></div>
      <div className="categories">{categories.map(c => <button key={c} onClick={() => setCategory(c)} className={category === c ? "chip active" : "chip"}>{c}</button>)}</div>
      {products.length === 0 ? <div className="empty">Menu is being prepared. Please check again soon.</div> :
        <div className="products">{shown.map(p => <article className="product" key={p.id}>
          <div className="foodImage">{p.image_url ? <img src={p.image_url} alt={p.name}/> : <span>🍛</span>}</div>
          <div className="productInfo"><h3>{p.name}</h3><p>{p.description}</p><div className="productBottom"><strong>{p.price.toLocaleString()} ETB</strong><button className="addBtn" onClick={() => add(p)}>＋ Add</button></div></div>
        </article>)}</div>}
    </section>

    <section className="section orderSection">
      <div className="sectionHead"><div><div className="eyebrow">YOUR ORDER</div><h2>Cart & checkout</h2></div><span className="pill">{cart.reduce((s,l)=>s+l.qty,0)} items</span></div>
      {cart.length === 0 ? <p className="muted">Your cart is empty. Add food from the menu above.</p> :
        <div className="cart">{cart.map(l => <div className="cartLine" key={l.product.id}><div><b>{l.product.name}</b><small>{l.product.price} ETB each</small></div><div className="qty"><button onClick={() => change(l.product.id,-1)}>−</button><b>{l.qty}</b><button onClick={() => change(l.product.id,1)}>＋</button></div><strong>{(l.product.price*l.qty).toLocaleString()} ETB</strong></div>)}</div>}
      <div className="total"><span>Subtotal</span><b>{total.toLocaleString()} ETB</b></div>
      <div className="formGrid">
        <label>Your name<input value={name} onChange={e=>setName(e.target.value)} placeholder="Full name"/></label>
        <label>Phone number<input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="09... or +251..."/></label>
        <label className="wide">Delivery address<input value={address} onChange={e=>setAddress(e.target.value)} placeholder="Area, street, landmark"/></label>
        <label className="wide">Note (optional)<textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="Extra instructions"/></label>
      </div>
      <button className="primary full" disabled={busy || cart.length===0} onClick={placeOrder}>{busy ? "Sending order..." : "Place order"}</button>
      {message && <div className="notice">{message}</div>}
      <p className="tiny">Payment and delivery fees are confirmed by the restaurant after order review.</p>
    </section>

    <section className="section trackSection">
      <div className="eyebrow">ORDER UPDATES</div><h2>Track your order</h2>
      <div className="formGrid"><label>Order code<input value={trackingCode} onChange={e=>setTrackingCode(e.target.value)} placeholder="ENAT-XXXXXX"/></label><label>Phone number<input value={trackingPhone} onChange={e=>setTrackingPhone(e.target.value)} placeholder="Phone used for order"/></label></div>
      <button className="secondary full" onClick={trackOrder}>Check order status</button>
      {trackingResult && <div className="notice">{trackingResult}</div>}
    </section>
    <footer>© {new Date().getFullYear()} Enat Food · Made with care in Ethiopia</footer>
  </main>;
}
