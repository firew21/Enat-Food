import { NextResponse } from "next/server";
import { adminSupabase } from "@/lib/supabase";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const code = (url.searchParams.get("code") || "").trim().toUpperCase();
  const phone = (url.searchParams.get("phone") || "").trim();
  if (!code || !phone) return NextResponse.json({ error: "Enter order code and phone." }, { status: 400 });
  const { data, error } = await adminSupabase().from("orders")
    .select("status,total").eq("order_code", code).eq("phone", phone).maybeSingle();
  if (error || !data) return NextResponse.json({ error: "Order not found. Check code and phone." }, { status: 404 });
  return NextResponse.json(data);
}
