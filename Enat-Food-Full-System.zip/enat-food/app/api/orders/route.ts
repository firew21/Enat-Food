import { NextResponse } from "next/server";
import { adminSupabase } from "@/lib/supabase";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { customer_name, phone, address, note, telegram_user_id, items } = body;
    if (!customer_name?.trim() || !phone?.trim() || !address?.trim() || !Array.isArray(items) || !items.length) {
      return NextResponse.json({ error: "Name, phone, address and at least one item are required." }, { status: 400 });
    }
    if (items.length > 30) return NextResponse.json({ error: "Too many different items." }, { status: 400 });

    const db = adminSupabase();
    const ids = [...new Set(items.map((i: any) => i.product_id))];
    const { data: products, error: productError } = await db.from("products")
      .select("id,name,price,is_available").in("id", ids);
    if (productError || !products || products.length !== ids.length) {
      return NextResponse.json({ error: "Some menu items are unavailable." }, { status: 400 });
    }
    let total = 0;
    const orderItems = [];
    for (const item of items) {
      const p = products.find((x: any) => x.id === item.product_id);
      const qty = Number(item.quantity);
      if (!p || !p.is_available || !Number.isInteger(qty) || qty < 1 || qty > 50) {
        return NextResponse.json({ error: "Invalid item or quantity." }, { status: 400 });
      }
      total += Number(p.price) * qty;
      orderItems.push({ product_id: p.id, product_name: p.name, unit_price: p.price, quantity: qty });
    }
    const order_code = "ENAT-" + Math.random().toString(36).slice(2, 8).toUpperCase();
    const { data: order, error } = await db.from("orders").insert({
      order_code, customer_name: customer_name.trim(), phone: phone.trim(),
      address: address.trim(), note: String(note || "").slice(0, 500),
      telegram_user_id: telegram_user_id ? String(telegram_user_id) : null,
      items: orderItems, total, status: "new"
    }).select("id,order_code").single();
    if (error) throw error;
    return NextResponse.json({ ok: true, order_code: order.order_code });
  } catch (e: any) {
    console.error("Order API error", e);
    return NextResponse.json({ error: "Could not save order. Check server configuration." }, { status: 500 });
  }
}
