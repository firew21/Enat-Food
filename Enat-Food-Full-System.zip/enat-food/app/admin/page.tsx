"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

export default function Admin() {
  const [session,setSession] = useState<any>(null);
  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");
  const [orders,setOrders] = useState<any[]>([]);
  const [products,setProducts] = useState<any[]>([]);
  const [msg,setMsg] = useState("");
  const [newName,setNewName] = useState("");
  const [newPrice,setNewPrice] = useState("");
  const [newCategory,setNewCategory] = useState("Main dishes");
  const [newDesc,setNewDesc] = useState("");

  useEffect(()=>{ supabase.auth.getSession().then(({data})=>setSession(data.session)); },[]);
  async function login(e:any) {
    e.preventDefault(); setMsg("");
    const {data,error}=await supabase.auth.signInWithPassword({email,password});
    if(error) setMsg(error.message); else setSession(data.session);
  }
  async function load() {
    const [o,p]=await Promise.all([
      supabase.from("orders").select("*").order("created_at",{ascending:false}).limit(100),
      supabase.from("products").select("*").order("created_at",{ascending:false})
    ]);
    if(o.error || p.error) setMsg("Could not load data. Check admin role and database policies.");
    setOrders(o.data||[]); setProducts(p.data||[]);
  }
  useEffect(()=>{ if(session) load(); },[session]);
  async function status(id:string,status:string) {
    const {error}=await supabase.from("orders").update({status}).eq("id",id);
    setMsg(error ? error.message : "Order status updated."); load();
  }
  async function addProduct(e:any) {
    e.preventDefault();
    const {error}=await supabase.from("products").insert({name:newName,price:Number(newPrice),category:newCategory,description:newDesc,is_available:true});
    setMsg(error ? error.message : "Menu item added.");
    if(!error){setNewName("");setNewPrice("");setNewDesc("");load();}
  }
  async function availability(id:string,value:boolean) {
    await supabase.from("products").update({is_available:value}).eq("id",id); load();
  }
  async function logout(){await supabase.auth.signOut();setSession(null);}
  if(!session) return <main className="adminPage"><a href="/">← Back to store</a><section className="adminCard"><div className="eyebrow">ENAT FOOD MANAGEMENT</div><h1>Admin login</h1><p className="muted">Sign in with the admin email created in Supabase.</p><form onSubmit={login} className="formGrid"><label className="wide">Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></label><label className="wide">Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required/></label><button className="primary full wide">Sign in</button></form>{msg&&<div className="notice">{msg}</div>}</section></main>;
  return <main className="adminPage"><header className="adminHeader"><div><div className="eyebrow">ENAT FOOD</div><h1>Admin dashboard</h1></div><button className="secondary" onClick={logout}>Sign out</button></header>
    {msg&&<div className="notice">{msg}</div>}
    <section className="adminCard"><div className="sectionHead"><h2>Orders</h2><button className="secondary" onClick={load}>Refresh</button></div>
      {orders.length===0?<p className="muted">No orders yet.</p>:orders.map(o=><article className="adminOrder" key={o.id}><div className="orderTop"><b>{o.order_code}</b><span className="pill">{o.status}</span></div><p><b>{o.customer_name}</b> · {o.phone}</p><p>{o.address}</p><p>{(o.items||[]).map((i:any)=>`${i.quantity} × ${i.product_name}`).join(", ")}</p><strong>{o.total} ETB</strong><div className="statusButtons">{["confirmed","preparing","on_the_way","delivered","cancelled"].map(s=><button key={s} className="chip" onClick={()=>status(o.id,s)}>{s.replaceAll("_"," ")}</button>)}</div></article>)}
    </section>
    <section className="adminCard"><h2>Add menu item</h2><form onSubmit={addProduct} className="formGrid"><label>Food name<input value={newName} onChange={e=>setNewName(e.target.value)} required/></label><label>Price (ETB)<input type="number" min="1" value={newPrice} onChange={e=>setNewPrice(e.target.value)} required/></label><label>Category<input value={newCategory} onChange={e=>setNewCategory(e.target.value)} required/></label><label className="wide">Description<input value={newDesc} onChange={e=>setNewDesc(e.target.value)}/></label><button className="primary full wide">Add food</button></form>
      <h3 className="subhead">Menu availability</h3>{products.map(p=><div className="menuAdmin" key={p.id}><span>{p.name} · {p.price} ETB</span><button className="chip" onClick={()=>availability(p.id,!p.is_available)}>{p.is_available?"Available":"Hidden"}</button></div>)}
    </section><a href="/">← Open customer app</a>
  </main>;
}
